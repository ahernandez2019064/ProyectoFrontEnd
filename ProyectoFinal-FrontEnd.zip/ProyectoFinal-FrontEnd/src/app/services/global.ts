export const CONNECTION ={
    URI: 'http://localhost:3000/'
}