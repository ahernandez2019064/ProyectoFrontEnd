
export const CONNECTION ={
   // URI: 'http://localhost:3000/',
    URI: 'https://gestortorneos.herokuapp.com/api'
}
