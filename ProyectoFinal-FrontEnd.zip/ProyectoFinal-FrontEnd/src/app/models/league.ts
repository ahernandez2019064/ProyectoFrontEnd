export class League {
    constructor(
        public _id: string,
        public name: string,
        public teams: [],
        public reports: [],
        public journey: []
    ){}
}