export class Report {
    constructor(
        public goals: Number,
        public goalsAgainst: Number,
        public score: Number,
    ){}
}