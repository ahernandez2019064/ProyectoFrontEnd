export class Journey {
    constructor(
        public _id: string,
        public journey: string,
        public soccerGame: []
    ){}
}